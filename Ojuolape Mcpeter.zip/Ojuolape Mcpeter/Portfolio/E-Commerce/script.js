let cart = JSON.parse(localStorage.getItem('cart')) || [];

function addToCart(name, price, qtyId) {
  const quantity = parseInt(document.getElementById(qtyId).value);
  const existing = cart.find(item => item.name === name);
  if (existing) {
    existing.quantity += quantity;
  } else {
    cart.push({ name, price, quantity });
  }
  localStorage.setItem('cart', JSON.stringify(cart));
  alert(`${quantity} x ${name} added to cart!`);
}

function removeFromCart(index) {
  cart.splice(index, 1);
  localStorage.setItem('cart', JSON.stringify(cart));
  loadCart();
}

function loadCart() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const cartList = document.getElementById('cart-items');
  cartList.innerHTML = '';
  let total = 0;

  cart.forEach((item, index) => {
    const li = document.createElement('li');
    li.innerHTML = `${item.quantity} x ${item.name} - $${(item.price * item.quantity).toFixed(2)}
      <button onclick="removeFromCart(${index})">Remove</button>`;
    cartList.appendChild(li);
    total += item.price * item.quantity;
  });

  document.getElementById('total').textContent = `Total: $${total.toFixed(2)}`;
}

function filterProducts() {
  const query = document.getElementById('search').value.toLowerCase();
  const products = document.querySelectorAll('.product');
  products.forEach(product => {
    const name = product.querySelector('h3').textContent.toLowerCase();
    product.style.display = name.includes(query) ? 'block' : 'none';
  });
}
