document.getElementById('add-task').addEventListener('click', function(){
    const input = document.getElementById('task-input');
    const taskInput = input.value.trim();

    if(taskInput !== '') {
        const li = document.createElement('li');
        li.textContent = taskInput;

        const deletebtn = document.createElement('button');
        deletebtn.textContent = 'Delete';
        deletebtn.onclick = function() {
            li.remove();
        };

        li.appendChild(deletebtn);
        document.getElementById('task-list').appendChild(li);
        input.value = '';
    }
});